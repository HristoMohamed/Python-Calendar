
from cal.models import *
from django.contrib import admin

admin.site.register(Entry, EntryAdmin)
